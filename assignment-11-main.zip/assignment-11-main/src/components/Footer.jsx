import React from 'react';

const Footer = () => {
    return (
        <div>
            <footer class="bg-dark text-white py-3">
            <div class="container">
                <div class="row">
                <div class="col-md-12">
                    <p class="text-center">&copy; 2023 Mehedi. All rights reserved.</p>
                </div>
                </div>
            </div>
            </footer>
        </div>
    );
};

export default Footer;